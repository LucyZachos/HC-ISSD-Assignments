/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question_2;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 * @author Lucy
 */
public class DrawRectangle extends MIDlet implements CommandListener {
    
    private boolean midletPaused = false;
    private Command exitCommand;
    private Form form;
    /**
     * The midlet constructor.
     */
    public DrawRectangle() {
    }
    /**
     * Initializes the application. It is called only once when the MIDlet is
     * started. The method is called before the <code>startMIDlet</code> method.
     */
    private void initialize() {
}
    /**
     * Performs an action assigned to the Mobile Device - MIDlet Started point.
     */
    public void startMIDlet() {
switchDisplayable(null, getForm());

}
    /**
     * Performs an action assigned to the Mobile Device - MIDlet Resumed point.
     */
    public void resumeMIDlet() {
}
    /**
     * Switches a current displayable in a display. The <code>display</code>
     * instance is taken from <code>getDisplay</code> method. This method is
     * used by all actions in the design for switching displayable.
     *
     * @param alert the Alert which is temporarily set to the display; if
     * <code>null</code>, then <code>nextDisplayable</code> is set immediately
     * @param nextDisplayable the Displayable to be set
     */
    public void switchDisplayable(Alert alert, Displayable nextDisplayable) {
Display display = getDisplay();
        if (alert == null) {
            display.setCurrent(nextDisplayable);
        } else {
            display.setCurrent(alert, nextDisplayable);
        }
}
    /**
     * Called by a system to indicated that a command has been invoked on a
     * particular displayable.
     *
     * @param command the Command that was invoked
     * @param displayable the Displayable where the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {
if (displayable == form) {
            if (command == exitCommand) {
exitMIDlet();
}
        }
}
    /**
     * Returns an initialized instance of exitCommand component.
     *
     * @return the initialized component instance
     */
    public Command getExitCommand() {
        if (exitCommand == null) {
exitCommand = new Command("Exit", Command.EXIT, 0);
}
        return exitCommand;
    }
    
    /**
     * Returns an initialized instance of form component.
     *
     * @return the initialized component instance
     */
    public Form getForm() {
        if (form == null) {
form = new Form("A shape within a shape", new Item[]{});
            form.addCommand(getExitCommand());
            form.setCommandListener(this);
}
        return form;
    }
    /**
     * Returns a display instance.
     *
     * @return the display instance.
     */
    public Display getDisplay() {
        return Display.getDisplay(this);
    }

    /**
     * Exits MIDlet.
     */
    public void exitMIDlet() {
        switchDisplayable(null, null);
        destroyApp(true);
        notifyDestroyed();
    }
    
    public void menuMIDlet() {
        switchDisplayable(null, null);
    }

    /**
     * Called when MIDlet is started. Checks whether the MIDlet have been
     * already started and initialize/starts or resumes the MIDlet.
     */
    public void startApp() {
        if (midletPaused) {
            resumeMIDlet();
        } else {
            initialize();
            startMIDlet();
        }
        midletPaused = false;
    }

    /**
     * Called when MIDlet is paused.
     */
    public void pauseApp() {
        midletPaused = true;
    }
    /**
     * Called to signal the MIDlet to terminate.
     *
     * @param unconditional if true, then the MIDlet has to be unconditionally
     * terminated and all resources has to be released.
     */
    public void destroyApp(boolean unconditional) {
    }
    
  class DrawingCanvas extends Canvas {
  public void paint (Graphics g) {
  g.setColor (217, 49, 255);//purple
  g.fillRect (0, 0, getWidth (), getHeight ());
  g.setColor (255, 0, 0);//red
  g.fillRect (20, 30, 200, 80);
  g.fillArc(150, 45, 20, 20, 0, 360);        
  g.setColor(255,255,255);//white
  }
}
}