package question_1_app;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 * @author Lucinda Frohlich
 */
public class ShapesMIDlet extends MIDlet implements CommandListener {
    
    private final Display display; 
    private final Form form;
    Command dots;
    Command squares;
    Command lines;
    private final StringItem shapestring;
    private final StringItem shape;
    
     public ShapesMIDlet(){
         
        display = Display.getDisplay(this); 
        form = new Form("Commands");
        dots = new Command("Dots", Command.ITEM, 1); 
        squares = new Command ("Sqaures", Command.ITEM,2);
        lines = new Command ("Lines", Command.ITEM,3);
        
        shapestring = new StringItem("Type: ","");
        shape = new StringItem ("Shape","");
           
        form.addCommand(dots); 
        form.addCommand(squares); 
        form.addCommand(lines); 
            
        form.setCommandListener(this); 
     }
     
     public void startApp() throws MIDletStateChangeException {       
         display.setCurrent(form);
     }
     public void pauseApp() {}
     
     public void commandAction(Command c, Displayable s){
              if(c == dots) { 
                    shapestring.setLabel("Dots");  
                    shape.setText(". . . . . ");
                }else if(c == squares){
                    shapestring.setLabel("Squares");  
                    shape.setText("▪ ▪ ▪ ▪ ▪");
                }else if(c == lines){
                    shapestring.setLabel("Squares");  
                    shape.setText("- - - - -");  
                }     
        }
    protected void destroyApp(boolean unconditional) throws MIDletStateChangeException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
       }